package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepSpaceBg = Color(0xFF070B14)
val MidnightSurface = Color(0xFF0F172A)
val NeonCyan = Color(0xFF22D3EE)
val SkyBlue = Color(0xFF38BDF8)
val CoralPink = Color(0xFFFB7185)
val TextPrimary = Color(0xFFF8FAFC)
val TextMuted = Color(0xFF94A3B8)
