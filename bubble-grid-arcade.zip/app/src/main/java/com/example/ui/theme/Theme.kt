package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val ArcadeDarkColorScheme =
  darkColorScheme(
    primary = NeonCyan,
    secondary = SkyBlue,
    tertiary = CoralPink,
    background = DeepSpaceBg,
    surface = MidnightSurface,
    onPrimary = DeepSpaceBg,
    onSecondary = DeepSpaceBg,
    onTertiary = DeepSpaceBg,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
  )

@Composable
fun MyApplicationTheme(
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = ArcadeDarkColorScheme,
    typography = Typography,
    content = content,
  )
}
