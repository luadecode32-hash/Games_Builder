package com.example

import android.annotation.SuppressLint
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  private var webViewRef: WebView? = null

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    configureImmersiveMode()
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

    setContent {
      MyApplicationTheme {
        DriveMasterWebShell(
          onWebViewCreated = { webViewRef = it },
          onExitApp = { finish() }
        )
      }
    }
  }

  private fun configureImmersiveMode() {
    WindowCompat.setDecorFitsSystemWindows(window, false)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
      window.attributes.layoutInDisplayCutoutMode =
        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }
    val controller = WindowInsetsControllerCompat(window, window.decorView)
    controller.hide(WindowInsetsCompat.Type.systemBars())
    controller.systemBarsBehavior =
      WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
  }

  override fun onWindowFocusChanged(hasFocus: Boolean) {
    super.onWindowFocusChanged(hasFocus)
    if (hasFocus) {
      configureImmersiveMode()
    }
  }

  override fun onPause() {
    super.onPause()
    webViewRef?.evaluateJavascript("window.onAndroidLifecycle && window.onAndroidLifecycle('pause');", null)
    webViewRef?.onPause()
  }

  override fun onResume() {
    super.onResume()
    webViewRef?.onResume()
    webViewRef?.evaluateJavascript("window.onAndroidLifecycle && window.onAndroidLifecycle('resume');", null)
  }

  override fun onDestroy() {
    webViewRef?.destroy()
    webViewRef = null
    super.onDestroy()
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun DriveMasterWebShell(
  onWebViewCreated: (WebView) -> Unit,
  onExitApp: () -> Unit
) {
  var isPageReady by remember { mutableStateOf(false) }
  var loadError by remember { mutableStateOf<String?>(null) }
  var webViewState by remember { mutableStateOf<WebView?>(null) }

  BackHandler {
    val wv = webViewState
    if (wv != null) {
      wv.evaluateJavascript("window.onAndroidBack ? window.onAndroidBack() : 'exit';") { result ->
        if (result == "\"exit\"" || result == "exit" || result == "null") {
          onExitApp()
        }
      }
    } else {
      onExitApp()
    }
  }

  DisposableEffect(Unit) {
    onDispose {
      webViewState = null
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF09142A))
  ) {
    AndroidView(
      modifier = Modifier.fillMaxSize(),
      factory = { context ->
        WebView(context).apply {
          setBackgroundColor(AndroidColor.parseColor("#09142A"))
          setLayerType(View.LAYER_TYPE_HARDWARE, null)
          isHapticFeedbackEnabled = false
          overScrollMode = View.OVER_SCROLL_NEVER

          settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = true
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            useWideViewPort = false
            loadWithOverviewMode = false
            cacheMode = WebSettings.LOAD_DEFAULT
          }

          webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
              isPageReady = true
            }

            override fun onReceivedError(
              view: WebView?,
              request: WebResourceRequest?,
              error: WebResourceError?
            ) {
              if (request?.isForMainFrame == true) {
                loadError = error?.description?.toString() ?: "Failed to load simulation"
              }
            }
          }

          webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
              return super.onConsoleMessage(consoleMessage)
            }
          }

          loadUrl("file:///android_asset/index.html")
          webViewState = this
          onWebViewCreated(this)
        }
      }
    )

    AnimatedVisibility(
      visible = !isPageReady && loadError == null,
      exit = fadeOut(),
      modifier = Modifier.fillMaxSize()
    ) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color(0xFF09142A)),
        contentAlignment = Alignment.Center
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          CircularProgressIndicator(
            color = Color(0xFF38BDF8),
            modifier = Modifier.size(48.dp)
          )
          Spacer(modifier = Modifier.height(16.dp))
          Text(
            text = "DRIVE MASTER 3D",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Initializing 3D Driving Engine...",
            color = Color(0xFF94A3B8),
            fontSize = 13.sp
          )
        }
      }
    }

    if (loadError != null) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color(0xFF09142A))
          .padding(24.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = "Unable to start simulation",
            color = Color.White,
            style = MaterialTheme.typography.titleLarge
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = loadError ?: "",
            color = Color(0xFF94A3B8),
            style = MaterialTheme.typography.bodyMedium
          )
          Spacer(modifier = Modifier.height(16.dp))
          Button(onClick = {
            loadError = null
            isPageReady = false
            webViewState?.reload()
          }) {
            Text("Retry")
          }
        }
      }
    }
  }
}
